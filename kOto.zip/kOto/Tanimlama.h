#ifndef TANIMLAMA_H
#define TANIMLAMA_H
#include <iostream>

using namespace std; 

class Tanimlama
{
	public:
		int numara; 
		char plaka[10], firma[20],  urun[20], sofor[30], tarih[20];  
		int ilkTartim, ikinciTartim, netTartim, durum ; 
		Tanimlama();
		~Tanimlama();
	
		
};

#endif

