#include <iostream>
#include "AnaEkran.h"

using namespace std; 

// KANTAR OTOMASYONU
// Bilgisayar M�hendisi Sad�k �AH�N 

int main(  ) {
	
	AnaEkran nesne ; 
	nesne.giris() ; 
	

	return 0;
}

