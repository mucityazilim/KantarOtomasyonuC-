#include "Sevkiyat.h"

Sevkiyat::Sevkiyat()
{
}

Sevkiyat::~Sevkiyat()
{
}

int Sevkiyat ::  sevkiyatNumarasiUret() 
{
	int  sayi=0; 
	ifstream file( "sevkiyatNo.txt" )  ; 
	while( (file.read ( (char   * )&sayi,sizeof(int )  ) )   != NULL ) 
	{
	}
	
	sayi++; 
	file.close(); 
//	cout<<"uretilecek numara "<< sayi << endl; 
	ofstream file2( "sevkiyatNo.txt", ios::app  ) ; 
	file2.write ( (char * )&sayi, sizeof(int )  )  ; 
	file2.close(); 
	return sayi ; 
}

void Sevkiyat :: aracGiris()
{
	cout<<"Arac girisi... "<< endl<< endl; 
	t1.numara = sevkiyatNumarasiUret() ; 	
	cout<<"Plaka     : " ; scanf(" %[^\n]s", t1.plaka ) ; 
	cout<<"Firma Adi : " ; scanf(" %[^\n]s", t1.firma ) ; 
	cout<<"Urun      : " ; scanf(" %[^\n]s", t1.urun ) ; 
	cout<<"Sofor     : " ; scanf(" %[^\n]s", t1.sofor ) ; 
	cout<<"ilk Tartim (kg) : " ; cin>>t1.ilkTartim;  
	cout<<"Tarih     : " ; scanf(" %[^\n]s", t1.tarih ) ; 
	t1.ikinciTartim= 0;
	t1.netTartim= 0;  
	t1.durum= 1;  
	
	ofstream file ("Sevkiyat.txt", ios::app  ) ; 
	file.write( (char * )&t1,sizeof(Tanimlama)  ) ; 
	file.close(); 
	cout<<"Arac giris kaydi tamam !"<< endl; 	
 } 
void Sevkiyat :: aracCikis()
{
	cout<<"Dolum icin bekleyen araclar ... "<< endl<< endl; 
	int i=0; 
	
	
	ifstream file ("Sevkiyat.txt"  ) ; 
	
	cout<<"NUMARA\t"<<"PLAKA\t"<<"1.TARTIM\t"<<endl; 
	while( (file.read ( (char * )&t1,sizeof(Tanimlama)  ) )   != NULL  ) 
	{
		if( t1.durum==1 )
		{
		i++; 
		cout<<t1.numara<< "\t" << t1.plaka << "\t"<< t1.ilkTartim << endl ;   			
		}
	 } 
	 
	file.close(); 
	if(i==0)
	{
	system("cls") ; 
	cout<<"\nBekleyen arac yok "<< endl; 
	}
	else
	{
		int no; 
		cout<<endl<< i<< " adet arac dolum icin beklemede !"<< endl; 
		cout<<"Cikis yapacak arac no : "; cin>>	no; 
		
		int durum2=0; 
		
		ifstream file ("Sevkiyat.txt"  ) ; 
	
		while( (file.read ( (char * )&t1,sizeof(Tanimlama)  ) )   != NULL  ) 
		{
			if( t1.durum==1 && t1.numara== no  )
			{
			durum2=1; 
			cout<<i<<" - "<< t1.numara<< " " << t1.plaka << " "<< t1.ilkTartim << endl;   			
			break; 
			}
		 } 
		 
		file.close(); 
		
		if( durum2==0) 
		cout<<"Hatali islem yaptiniz ! "<< endl; 
		else 
		{
			cout<<"Son tartim (kg) : "; cin>>t1.ikinciTartim; 
			
			t1.netTartim = t1.ikinciTartim - t1.ilkTartim  ; 
			t1.durum= 2; 
			
			
			Tanimlama t2; 
			ifstream file ("Sevkiyat.txt"  ) ; 
			ofstream yaz ("Sevkiyat2.txt", ios::app  ) ; 
	
			while( (file.read ( (char * )&t2,sizeof(Tanimlama)  ) )   != NULL  ) 
			{
				if( t2.durum==1  && t2.numara== t1.numara   )
				{
					t2= t1; 
				}
				yaz.write( (char * )&t2,sizeof(Tanimlama)  ) ; 
				
			 } 
			 
			file.close(); 
			yaz.close(); 
			
			remove("Sevkiyat.txt") ; 
			rename("Sevkiyat2.txt", "Sevkiyat.txt" ) ; 
			cout<<"Cikis yapildi "<< endl; 
		} 
		
	 } 
	
	
	
	
 } 
void Sevkiyat :: bekleyenAraclar()
{
	cout<<"Bekleyen araclar ... "<< endl<< endl; 
	int i=0; 
	
	
	ifstream file ("Sevkiyat.txt"  ) ; 
	
	cout<<"NUMARA\t"<<"PLAKA\t"<<"1.TARTIM\t"<<endl; 
	while( (file.read ( (char * )&t1,sizeof(Tanimlama)  ) )   != NULL  ) 
	{
		if( t1.durum==1 )
		{
		i++; 
		cout<<t1.numara<< "\t" << t1.plaka << "\t"<< t1.ilkTartim << endl ;   			
		}
	 } 
	 
	file.close(); 
	if(i==0)
	{
	system("cls") ; 
	cout<<"\nBekleyen arac yok "<< endl; 
	}
	else 
	cout<<endl<< i<< " adet arac beklemede !"<< endl; 	
}
void Sevkiyat :: raporlar()
{
	cout<<"Rapor ... "<< endl<< endl; 
	int i=0; 
	int toplam=0; 
	
	ifstream file ("Sevkiyat.txt"  ) ; 
	
	while( (file.read ( (char * )&t1,sizeof(Tanimlama)  ) )   != NULL  ) 
	{
		if( t1.durum==2 )
		{
		i++; 
		cout<<i<<" - "<< t1.numara<< " " << t1.urun << " "<< t1.netTartim << " " << endl ;   			
		toplam += t1.netTartim ; 
		}
	 } 
	 
	file.close(); 
	if(i==0)
	cout<<"\nUrun sevkiyati olmamistir  "<< endl; 
	else 
	{
	cout<<endl<< i<< " adet urun sevkiyati olmustur   !"<< endl; 	
	cout<<endl<< " Net toplam  :   " << toplam << " kg. " << endl;
	}
	
	
	
 } 
int Sevkiyat :: menu()
{
	int  secim; 
	
	cout<<"\n\tSevkiyat  ISLEMLERI "<< endl; 
	cout<<"\t1- Arac girisi "<< endl; 
	cout<<"\t2- Arac cikisi "<< endl; 
	cout<<"\t3- Bekleyen araclar "<< endl; 
	cout<<"\t4- Raporlar  "<< endl; 
	cout<<"\t0- Anamenu "<< endl; 
	cout<<"\tSeciminiz  [0-4] : "; cin>>secim; 
		
	return secim; 
	
 } 
void Sevkiyat :: giris()
{
	int secim= menu(); 
	while( secim != 0 ) 
	{
		switch(secim )
		{
			case 1: aracGiris(); break; 
			case 2: aracCikis(); break; 
			case 3: bekleyenAraclar(); break; 
			case 4: raporlar(); break; 
			case 0: break; 
			default: cout<<"Hatali secim ! "<< endl; break; 
		} 
		secim= menu(); 
		system("cls") ; 
	} 
 } 




