#ifndef SEVKIYAT_H
#define SEVKIYAT_H

#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <fstream>
#include "Tanimlama.h"

class Sevkiyat
{
	public:
		Sevkiyat();
		~Sevkiyat();
	 Tanimlama t1; 	
	int sevkiyatNumarasiUret() ; 
	void aracGiris(); 
	void aracCikis(); 
	void bekleyenAraclar(); 
	void raporlar(); 
	int menu(); 
	void giris(); 
};

#endif

