#ifndef Stok_H
#define Stok_H
#include <iostream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include <fstream>
#include "Tanimlama.h"

using namespace std; 

class Stok 
{
	public:
		Stok ();
		~Stok ();
	Tanimlama t1; 	
	int stokNumarasiUret() ; 
	void aracGiris(); 
	void aracCikis(); 
	void bekleyenAraclar(); 
	void raporlar(); 
	int menu(); 
	void giris(); 
	
		
};

#endif

