#include "Tanimlama.h"

Tanimlama::Tanimlama()
{
}

Tanimlama::~Tanimlama()
{
}



